package Entity;

public class Categoria {

	private int id_catogoria;
	private String nombre;
	
	
	public int getId_catogoria() {
		return id_catogoria;
	}
	public void setId_catogoria(int id_catogoria) {
		this.id_catogoria = id_catogoria;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
}
